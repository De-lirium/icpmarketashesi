export const idlFactory = ({ IDL }) => {
  const PublicAuction = IDL.Record({
    'id' : IDL.Nat,
    'startTime' : IDL.Int,
    'startingPrice' : IDL.Nat,
    'highestBidder' : IDL.Opt(IDL.Principal),
    'endTime' : IDL.Int,
    'isActive' : IDL.Bool,
    'highestBid' : IDL.Nat,
    'nftId' : IDL.Nat,
  });
  const PublicNFT = IDL.Record({
    'id' : IDL.Nat,
    'title' : IDL.Text,
    'owner' : IDL.Principal,
    'isListed' : IDL.Bool,
    'description' : IDL.Text,
    'category' : IDL.Text,
    'image' : IDL.Vec(IDL.Nat8),
    'price' : IDL.Nat,
  });
  const UserProfile = IDL.Record({
    'bio' : IDL.Text,
    'username' : IDL.Text,
    'profilePicture' : IDL.Vec(IDL.Nat8),
  });
  const UpdateResult = IDL.Variant({
    'Success' : UserProfile,
    'UpdateFailed' : IDL.Text,
    'UserNotFound' : IDL.Text,
  });
  return IDL.Service({
    'createAuction' : IDL.Func(
        [IDL.Nat, IDL.Nat, IDL.Int, IDL.Int],
        [IDL.Opt(PublicAuction)],
        [],
      ),
    'endAuction' : IDL.Func([IDL.Nat], [IDL.Bool], []),
    'getActiveAuctions' : IDL.Func([], [IDL.Vec(PublicAuction)], ['query']),
    'getImage' : IDL.Func([IDL.Nat], [IDL.Opt(IDL.Vec(IDL.Nat8))], ['query']),
    'getNFTs' : IDL.Func([], [IDL.Vec(PublicNFT)], ['query']),
    'listNFT' : IDL.Func([IDL.Nat], [IDL.Bool], []),
    'mintNFT' : IDL.Func(
        [IDL.Vec(IDL.Nat8), IDL.Text, IDL.Text, IDL.Text],
        [PublicNFT],
        [],
      ),
    'placeBid' : IDL.Func([IDL.Nat, IDL.Nat], [IDL.Bool], []),
    'purchaseNFT' : IDL.Func([IDL.Nat], [IDL.Bool], []),
    'registerUser' : IDL.Func(
        [IDL.Text, IDL.Text, IDL.Vec(IDL.Nat8)],
        [IDL.Bool],
        [],
      ),
    'updateProfile' : IDL.Func(
        [IDL.Text, IDL.Text, IDL.Vec(IDL.Nat8)],
        [UpdateResult],
        [],
      ),
    'uploadImage' : IDL.Func([IDL.Vec(IDL.Nat8)], [IDL.Text], []),
  });
};
export const init = ({ IDL }) => { return []; };
