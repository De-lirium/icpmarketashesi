import type { Principal } from '@dfinity/principal';
import type { ActorMethod } from '@dfinity/agent';
import type { IDL } from '@dfinity/candid';

export interface PublicAuction {
  'id' : bigint,
  'startTime' : bigint,
  'startingPrice' : bigint,
  'highestBidder' : [] | [Principal],
  'endTime' : bigint,
  'isActive' : boolean,
  'highestBid' : bigint,
  'nftId' : bigint,
}
export interface PublicNFT {
  'id' : bigint,
  'title' : string,
  'owner' : Principal,
  'isListed' : boolean,
  'description' : string,
  'category' : string,
  'image' : Uint8Array | number[],
  'price' : bigint,
}
export type UpdateResult = { 'Success' : UserProfile } |
  { 'UpdateFailed' : string } |
  { 'UserNotFound' : string };
export interface UserProfile {
  'bio' : string,
  'username' : string,
  'profilePicture' : Uint8Array | number[],
}
export interface _SERVICE {
  'createAuction' : ActorMethod<
    [bigint, bigint, bigint, bigint],
    [] | [PublicAuction]
  >,
  'endAuction' : ActorMethod<[bigint], boolean>,
  'getActiveAuctions' : ActorMethod<[], Array<PublicAuction>>,
  'getImage' : ActorMethod<[bigint], [] | [Uint8Array | number[]]>,
  'getNFTs' : ActorMethod<[], Array<PublicNFT>>,
  'listNFT' : ActorMethod<[bigint], boolean>,
  'mintNFT' : ActorMethod<
    [Uint8Array | number[], string, string, string],
    PublicNFT
  >,
  'placeBid' : ActorMethod<[bigint, bigint], boolean>,
  'purchaseNFT' : ActorMethod<[bigint], boolean>,
  'registerUser' : ActorMethod<
    [string, string, Uint8Array | number[]],
    boolean
  >,
  'updateProfile' : ActorMethod<
    [string, string, Uint8Array | number[]],
    UpdateResult
  >,
  'uploadImage' : ActorMethod<[Uint8Array | number[]], string>,
}
export declare const idlFactory: IDL.InterfaceFactory;
export declare const init: (args: { IDL: typeof IDL }) => IDL.Type[];
