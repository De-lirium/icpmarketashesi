import { BrowserRouter, Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import Marketplace from './pages/Marketplace';
import CreateNFT from './pages/CreateNFT';
import Artists from './pages/Artists';
import About from './pages/About';
import Heritage from './pages/Heritage';
import { AuthProvider } from './contexts/AuthContext';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-gray-50">
          <NavBar />
          <Routes>
            <Route path="/" element={<Marketplace />} />
            <Route path="/create" element={<CreateNFT />} />
            <Route path="/artists" element={<Artists />} />
            <Route path="/about" element={<About />} />
            <Route path="/heritage" element={<Heritage />} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;