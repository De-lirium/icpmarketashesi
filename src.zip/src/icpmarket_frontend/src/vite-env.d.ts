/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly DFX_NETWORK?: string;
  readonly CANISTER_ID_ICPMARKET_BACKEND?: string;
  readonly CANISTER_ID_INTERNET_IDENTITY?: string;
  readonly CANISTER_ID_ICPMARKET_FRONTEND?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
