import { Principal } from '@dfinity/principal';
import { NFT, UserProfile, UpdateProfileResult, Auction } from '../types';
import { Actor, HttpAgent, Identity } from '@dfinity/agent';
import { idlFactory } from '../declarations/icpmarket_backend';

// Determine if we're in a local development environment
const isLocalDev = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

// Get the canister ID from environment or use a default for local development
const canisterId = isLocalDev
  ? 'be2us-64aaa-aaaaa-qaabq-cai'  // Local development canister ID
  : import.meta.env.CANISTER_ID_ICPMARKET_BACKEND || 'be2us-64aaa-aaaaa-qaabq-cai';  // Production canister ID

// Get the host based on environment
const host = isLocalDev
  ? 'http://localhost:4943'
  : 'https://icp0.io';

console.log('Backend canister ID:', canisterId);
console.log('Host:', host);
console.log('Environment:', isLocalDev ? 'local' : 'production');

// Initialize the HttpAgent with the appropriate host
const agent = new HttpAgent({
  host,
});

// Only fetch the root key in local development
if (isLocalDev) {
  agent.fetchRootKey().catch(err => {
    console.warn('Unable to fetch root key. Check to ensure that your local replica is running');
    console.error(err);
  });
}

// Initialize the backend actor with optional identity
export const initializeBackend = async (identity?: any) => {
  try {
    if (identity) {
      agent.replaceIdentity(identity);
    }

    // Create the actor with the current agent
    const actor = Actor.createActor(idlFactory, {
      agent,
      canisterId,
    });

    console.log('Backend actor initialized successfully');
    return actor;
  } catch (error) {
    console.error('Failed to initialize backend actor:', error);
    throw error;
  }
};

// Initialize a default backend with no identity
let backend: any = null;

export const getBackend = async () => {
  if (!backend) {
    backend = await initializeBackend();
  }
  return backend;
};

// API functions
export const mintNFT = async (title: string, description: string, image: Uint8Array, category: string) => {
  try {
    const actor = await getBackend();
    console.log('Minting NFT with title:', title);
    const result = await actor.mintNFT(image, title, description, category);
    console.log('NFT minted successfully:', result);
    return result;
  } catch (error) {
    console.error('Error minting NFT:', error);
    throw error;
  }
};

export const getNFTs = async () => {
  try {
    const actor = await getBackend();
    console.log('Fetching NFTs...');
    const nfts = await actor.getNFTs();
    console.log('NFTs fetched successfully:', nfts);
    return nfts;
  } catch (error) {
    console.error('Error fetching NFTs:', error);
    throw error;
  }
};

export const uploadImage = async (image: Uint8Array) => {
  try {
    const actor = await getBackend();
    console.log('Uploading image...');
    const result = await actor.uploadImage(image);
    console.log('Image uploaded successfully:', result);
    return result;
  } catch (error) {
    console.error('Error uploading image:', error);
    throw error;
  }
};

export const getImage = async (index: number) => {
  try {
    const actor = await getBackend();
    console.log('Fetching image at index:', index);
    const image = await actor.getImage(index);
    console.log('Image fetched successfully');
    return image;
  } catch (error) {
    console.error('Error fetching image:', error);
    throw error;
  }
};

export const listNFT = async (nftId: bigint) => {
  try {
    const actor = await getBackend();
    console.log('Listing NFT:', nftId);
    const result = await actor.listNFT(nftId);
    console.log('NFT listed successfully:', result);
    return result;
  } catch (error) {
    console.error('Error listing NFT:', error);
    throw error;
  }
};

export const purchaseNFT = async (nftId: bigint) => {
  try {
    const actor = await getBackend();
    console.log('Purchasing NFT:', nftId);
    const result = await actor.purchaseNFT(nftId);
    console.log('NFT purchased successfully:', result);
    return result;
  } catch (error) {
    console.error('Error purchasing NFT:', error);
    throw error;
  }
};

/**
 * Register a new user
 * @param username Username
 * @param bio User bio
 * @param profilePicture Profile picture as Uint8Array
 * @returns Success status
 */
export async function registerUser(
  username: string,
  bio: string,
  profilePicture: Uint8Array
): Promise<boolean> {
  if (!backend) {
    throw new Error("Backend actor not initialized");
  }
  const result = await backend.registerUser(username, bio, profilePicture);
  return result as boolean;
}

/**
 * Update user profile
 * @param username Username
 * @param bio User bio
 * @param profilePicture Profile picture as Uint8Array
 * @returns Update result
 */
export async function updateProfile(
  username: string,
  bio: string,
  profilePicture: Uint8Array
): Promise<UpdateProfileResult> {
  if (!backend) {
    throw new Error("Backend actor not initialized");
  }
  const result = await backend.updateProfile(username, bio, profilePicture);
  return result as unknown as UpdateProfileResult;
}

/**
 * Create a new auction
 * @param nftId ID of the NFT
 * @param startingPrice Starting price of the auction
 * @param startTime Start time of the auction
 * @param endTime End time of the auction
 * @returns Created auction or null
 */
export async function createAuction(
  nftId: bigint,
  startingPrice: bigint,
  startTime: bigint,
  endTime: bigint
): Promise<Auction | null> {
  if (!backend) {
    throw new Error("Backend actor not initialized");
  }
  const result = await backend.createAuction(nftId, startingPrice, startTime, endTime);
  return result as unknown as Auction | null;
}

/**
 * Place a bid on an auction
 * @param auctionId ID of the auction
 * @param amount Bid amount
 * @returns Success status
 */
export async function placeBid(auctionId: bigint, amount: bigint): Promise<boolean> {
  if (!backend) {
    throw new Error("Backend actor not initialized");
  }
  const result = await backend.placeBid(auctionId, amount);
  return result as boolean;
}

/**
 * End an auction
 * @param auctionId ID of the auction
 * @returns Success status
 */
export async function endAuction(auctionId: bigint): Promise<boolean> {
  if (!backend) {
    throw new Error("Backend actor not initialized");
  }
  const result = await backend.endAuction(auctionId);
  return result as boolean;
}

/**
 * Get all active auctions
 * @returns Array of active auctions
 */
export async function getActiveAuctions(): Promise<Auction[]> {
  if (!backend) {
    throw new Error("Backend actor not initialized");
  }
  const result = await backend.getActiveAuctions();
  return result as unknown as Auction[];
}