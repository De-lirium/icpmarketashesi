import React, { useState, useEffect } from 'react';
import ArtworkCard from '../components/ArtworkCard';
import { getNFTs, listNFT, purchaseNFT } from '../lib/canister';
import { NFT } from '../types';

const CATEGORIES = ['All Categories', 'Digital Art', 'Photography', '3D Models', 'Music'] as const;
type Category = typeof CATEGORIES[number];

export default function Marketplace() {
  const [nfts, setNFTs] = useState<NFT[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category>('All Categories');
  const [sortOption, setSortOption] = useState('Recently Listed');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    console.log("Marketplace component mounted");
    fetchNFTs();
  }, []);

  const fetchNFTs = async () => {
    console.log("Starting to fetch NFTs");
    try {
      setLoading(true);
      setError(null);
      console.log("Calling getNFTs...");
      const fetchedNFTs = await getNFTs();
      console.log("Fetched NFTs successfully:", fetchedNFTs);
      setNFTs(fetchedNFTs as NFT[]);
    } catch (error) {
      console.error('Error fetching NFTs:', error);
      setError('Failed to load NFTs. Please ensure your local replica is running and try again. Error: ' + (error instanceof Error ? error.message : String(error)));
      setNFTs([]); // Reset NFTs on error
    } finally {
      setLoading(false);
      console.log("Finished fetching NFTs");
    }
  };

  const handlePurchase = async (nftId: bigint) => {
    try {
      const success = await purchaseNFT(nftId);
      if (success) {
        fetchNFTs(); // Refresh the list after purchase
      }
    } catch (error) {
      console.error('Error purchasing NFT:', error);
    }
  };

  const handleList = async (nftId: bigint) => {
    try {
      const success = await listNFT(nftId);
      if (success) {
        fetchNFTs(); // Refresh the list after listing
      }
    } catch (error) {
      console.error('Error listing NFT:', error);
    }
  };

  const filteredNFTs = nfts.filter(nft => {
    const matchesSearch = nft.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         nft.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All Categories' || nft.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedNFTs = [...filteredNFTs].sort((a, b) => {
    switch (sortOption) {
      case 'Price: Low to High':
        return Number(a.price - b.price);
      case 'Price: High to Low':
        return Number(b.price - a.price);
      default:
        return 0;
    }
  });

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#FFD700]"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold mb-6">Marketplace</h1>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div className="flex flex-wrap gap-3 mb-4 md:mb-0">
            {CATEGORIES.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`${
                  selectedCategory === category
                    ? 'bg-[#FFD700] text-black'
                    : 'bg-white text-black hover:bg-gray-100'
                } px-4 py-2 rounded-full text-sm`}
              >
                {category}
              </button>
            ))}
          </div>
          
          <div className="flex items-center w-full md:w-auto">
            <div className="relative w-full md:w-auto mr-4">
              <input
                type="text"
                placeholder="Search artwork..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#FFD700] focus:border-transparent"
              />
            </div>
            
            <div className="relative">
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-[#FFD700]"
              >
                <option>Recently Listed</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {sortedNFTs.map((nft) => (
          <ArtworkCard 
            key={nft.id.toString()}
            id={nft.id}
            title={nft.title}
            artist={nft.owner.toString()}
            price={nft.price}
            image={URL.createObjectURL(new Blob([nft.image]))}
            status={nft.isListed ? 'forSale' : 'notListed'}
            onPurchase={() => handlePurchase(nft.id)}
            onList={() => handleList(nft.id)}
          />
        ))}
      </div>
      
      {sortedNFTs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No NFTs found matching your criteria.</p>
        </div>
      )}
    </div>
  );
} 