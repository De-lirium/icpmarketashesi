import React, { useState, FormEvent, ChangeEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { mintNFT } from '../lib/canister';

export default function CreateNFT() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    price: '',
    region: '',
    royalty: '10',
    culturalContext: '',
    acceptTerms: false
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        setError('File size exceeds 50MB limit');
        return;
      }
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
      setError(null);
    }
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
    setError(null);
  };

  const handleCheckboxChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, acceptTerms: e.target.checked }));
  };

  const validateForm = () => {
    if (!selectedFile) {
      setError('Please upload an artwork file');
      return false;
    }
    if (!formData.title.trim()) {
      setError('Please enter a title');
      return false;
    }
    if (!formData.description.trim()) {
      setError('Please enter a description');
      return false;
    }
    if (!formData.category) {
      setError('Please select a category');
      return false;
    }
    if (!formData.price || Number(formData.price) <= 0) {
      setError('Please enter a valid price');
      return false;
    }
    if (!formData.region) {
      setError('Please select a region');
      return false;
    }
    if (!formData.acceptTerms) {
      setError('Please accept the terms of service');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Convert file to Uint8Array
      const fileBuffer = await selectedFile!.arrayBuffer();
      const imageData = new Uint8Array(fileBuffer);

      // Create NFT with required parameters
      const nft = await mintNFT(
        formData.title,
        formData.description,
        imageData,
        formData.category
      );

      console.log("NFT created:", nft);
      // Redirect to the NFT's page or marketplace
      navigate('/marketplace');
    } catch (err) {
      setError('Failed to create NFT. Please try again.');
      console.error('Error creating NFT:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 flex flex-col items-center">
      <h1 className="text-3xl font-bold mb-6 text-center">Create African Art NFT</h1>
      
      <div className="card max-w-3xl w-full bg-white p-8 rounded-lg shadow-md mx-auto">
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="image" className="block mb-2 font-medium">Upload Artwork</label>
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-[#FFD700] transition-colors"
              onClick={() => document.getElementById('image')?.click()}
            >
              {previewUrl ? (
                <div className="mb-4">
                  <img src={previewUrl} alt="Preview" className="max-h-48 mx-auto" />
                </div>
              ) : (
                <div className="mb-4">
                  <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                  </svg>
                </div>
              )}
              <p className="text-gray-600 mb-2">Drag and drop your African artwork here, or click to browse</p>
              <p className="text-sm text-gray-500 mb-4">Supported formats: JPG, PNG, GIF, SVG, MP4. Max size: 50MB</p>
              <input 
                type="file" 
                id="image" 
                className="hidden" 
                accept="image/*,video/mp4"
                onChange={handleFileChange}
              />
              <button type="button" className="btn bg-black text-[#FFD700] py-2 px-4 rounded-md hover:bg-gray-900 border border-[#FFD700]">
                Browse Files
              </button>
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="title" className="block mb-2 font-medium">Title</label>
            <input 
              type="text" 
              id="title" 
              value={formData.title}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded-md p-3 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20" 
              placeholder="Enter artwork title"
            />
          </div>

          <div className="mb-6">
            <label htmlFor="description" className="block mb-2 font-medium">Description</label>
            <textarea 
              id="description" 
              value={formData.description}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded-md p-3 h-32 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20" 
              placeholder="Describe your artwork, its cultural significance, and inspiration..."
            ></textarea>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="category" className="block mb-2 font-medium">Category</label>
              <select 
                id="category" 
                value={formData.category}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md p-3 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20"
              >
                <option value="">Select Category</option>
                <option value="traditional">Traditional</option>
                <option value="contemporary">Contemporary African</option>
                <option value="sculpture">Sculpture & Masks</option>
                <option value="textile">Textile Art</option>
                <option value="painting">Painting</option>
                <option value="digital">Digital African Art</option>
                <option value="heritage">Heritage Inspired</option>
              </select>
            </div>
            <div>
              <label htmlFor="price" className="block mb-2 font-medium">Price (ICP)</label>
              <input 
                type="number" 
                id="price" 
                value={formData.price}
                onChange={handleInputChange}
                min="0.01" 
                step="0.01" 
                className="w-full border border-gray-300 rounded-md p-3 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20" 
                placeholder="Set your price"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="region" className="block mb-2 font-medium">Region</label>
              <select 
                id="region" 
                value={formData.region}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md p-3 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20"
              >
                <option value="">Select Region</option>
                <option value="west">West Africa</option>
                <option value="east">East Africa</option>
                <option value="north">North Africa</option>
                <option value="south">Southern Africa</option>
                <option value="central">Central Africa</option>
              </select>
            </div>
            <div>
              <label htmlFor="royalty" className="block mb-2 font-medium">Royalty Percentage</label>
              <input 
                type="number" 
                id="royalty" 
                value={formData.royalty}
                onChange={handleInputChange}
                min="0" 
                max="15" 
                step="0.5"
                className="w-full border border-gray-300 rounded-md p-3 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20" 
                placeholder="Set royalty percentage (0-15%)"
              />
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="culturalContext" className="block mb-2 font-medium">Cultural Context (Optional)</label>
            <textarea 
              id="culturalContext" 
              value={formData.culturalContext}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded-md p-3 h-24 focus:border-[#FFD700] focus:ring focus:ring-[#FFD700]/20" 
              placeholder="Share the cultural significance, historical context, or traditional meaning behind your artwork..."
            ></textarea>
          </div>

          <div className="mb-6">
            <label className="flex items-center">
              <input 
                type="checkbox" 
                checked={formData.acceptTerms}
                onChange={handleCheckboxChange}
                className="mr-2 h-5 w-5 text-black focus:ring-[#FFD700]" 
              />
              <span>I confirm that I own the rights to this artwork and accept the terms of service</span>
            </label>
          </div>

          <div className="flex justify-center space-x-4">
            <button 
              type="button" 
              className="btn bg-gray-500 hover:bg-gray-600 text-white py-2 px-6 rounded-md"
              disabled={loading}
            >
              Preview
            </button>
            <button 
              type="submit" 
              className="btn bg-black text-[#FFD700] py-2 px-6 rounded-md hover:bg-gray-900 border border-[#FFD700]"
              disabled={loading || !formData.acceptTerms}
            >
              {loading ? 'Creating...' : 'Create NFT'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
} 