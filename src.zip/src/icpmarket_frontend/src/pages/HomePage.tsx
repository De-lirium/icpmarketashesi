import React from 'react';
import EventBanner from '../components/EventBanner';
import { NFT } from '../types';

interface HomePageProps {
  featuredArtworks: NFT[];
}

const HomePage: React.FC<HomePageProps> = ({ featuredArtworks }) => {
  // Get top 3 featured artwork for the carousel
  const topFeatured = featuredArtworks.slice(0, 3);

  return (
    <>
      <EventBanner />
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center">
          <div className="w-full md:w-2/3 text-center mb-10">
            <h1 className="text-4xl font-bold mb-6">African NFT Marketplace</h1>
            <p className="text-gray-600 mb-8 text-lg">
              Discover and collect authentic African art, from traditional indigenous masterpieces to contemporary works, while supporting artists and preserving cultural heritage.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-10">
              <a href="/marketplace" className="bg-black text-[#FFD700] px-6 py-3 rounded-lg font-medium hover:bg-gray-900 border border-[#FFD700]">
                Explore Artwork
              </a>
              <a href="#heritage" className="border border-black text-black px-6 py-3 rounded-lg font-medium hover:bg-gray-100">
                Explore Heritage
              </a>
            </div>
          </div>

          {/* Carousel with Fish Eye Effect */}
          <div className="flex transition-transform duration-500 ease-in-out transform" 
               style={{width: '300%', animation: 'carousel 15s infinite linear'}}>
            {/* First slide */}
            <div className="w-1/3 flex justify-center px-4">
              {topFeatured.map((nft, index) => (
                <div key={`hero-slide1-${nft.id}`} 
                     className="w-1/3 bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition duration-300 mx-2"
                     style={{
                       transform: index === 1 ? 'scale(1.15)' : 'scale(0.9)',
                       zIndex: index === 1 ? 10 : 1,
                       transition: 'all 0.3s ease'
                     }}>
                  <img 
                    src={nft.image && nft.image.length > 0 
                      ? `data:image/jpeg;base64,${btoa(String.fromCharCode(...nft.image))}` 
                      : `/placeholder-${Number(nft.id)}.jpg`} 
                    alt={nft.title} 
                    className="w-full h-auto" 
                  />
                  <div className="p-4">
                    <h3 className="font-bold text-lg">{nft.title}</h3>
                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <img src="/placeholder-avatar.jpg" alt="Artist" className="w-6 h-6 rounded-full mr-2" />
                      <span>{nft.owner.toString().slice(0, 10)}</span>
                    </div>
                    <div className="flex justify-between items-center mt-4">
                      <span className="text-[#FFD700] font-bold">{(Number(nft.id) % 5 + 1.5).toFixed(1)} ICP</span>
                      <span className={`${index % 2 === 0 ? 'bg-gray-100 text-black' : 'bg-gray-800 text-white'} px-2 py-1 rounded-full text-xs`}>
                        {index % 2 === 0 ? 'Auction' : 'Buy Now'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Second slide - same NFTs in different order */}
            <div className="w-1/3 flex justify-center px-4">
              {topFeatured.slice().reverse().map((nft, index) => (
                <div key={`hero-slide2-${nft.id}`} 
                     className="w-1/3 bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition duration-300 mx-2"
                     style={{
                       transform: index === 1 ? 'scale(1.15)' : 'scale(0.9)',
                       zIndex: index === 1 ? 10 : 1,
                       transition: 'all 0.3s ease'
                     }}>
                  <img 
                    src={nft.image && nft.image.length > 0 
                      ? `data:image/jpeg;base64,${btoa(String.fromCharCode(...nft.image))}` 
                      : `/placeholder-${Number(nft.id)}.jpg`} 
                    alt={nft.title} 
                    className="w-full h-auto" 
                  />
                  <div className="p-4">
                    <h3 className="font-bold text-lg">{nft.title}</h3>
                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <img src="/placeholder-avatar.jpg" alt="Artist" className="w-6 h-6 rounded-full mr-2" />
                      <span>{nft.owner.toString().slice(0, 10)}</span>
                    </div>
                    <div className="flex justify-between items-center mt-4">
                      <span className="text-[#FFD700] font-bold">{(Number(nft.id) % 5 + 1.5).toFixed(1)} ICP</span>
                      <span className={`${index % 2 === 0 ? 'bg-gray-800 text-white' : 'bg-gray-100 text-black'} px-2 py-1 rounded-full text-xs`}>
                        {index % 2 === 0 ? 'Buy Now' : 'Auction'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Third slide - mixed order */}
            <div className="w-1/3 flex justify-center px-4">
              {[...topFeatured].sort((a, b) => Number(a.id) - Number(b.id)).map((nft, index) => (
                <div key={`hero-slide3-${nft.id}`} 
                     className="w-1/3 bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition duration-300 mx-2"
                     style={{
                       transform: index === 1 ? 'scale(1.15)' : 'scale(0.9)',
                       zIndex: index === 1 ? 10 : 1,
                       transition: 'all 0.3s ease'
                     }}>
                  <img 
                    src={nft.image && nft.image.length > 0 
                      ? `data:image/jpeg;base64,${btoa(String.fromCharCode(...nft.image))}` 
                      : `/placeholder-${Number(nft.id)}.jpg`} 
                    alt={nft.title} 
                    className="w-full h-auto" 
                  />
                  <div className="p-4">
                    <h3 className="font-bold text-lg">{nft.title}</h3>
                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <img src="/placeholder-avatar.jpg" alt="Artist" className="w-6 h-6 rounded-full mr-2" />
                      <span>{nft.owner.toString().slice(0, 10)}</span>
                    </div>
                    <div className="flex justify-between items-center mt-4">
                      <span className="text-[#FFD700] font-bold">{(Number(nft.id) % 5 + 1.5).toFixed(1)} ICP</span>
                      <span className={`${index % 2 === 0 ? 'bg-gray-100 text-black' : 'bg-gray-800 text-white'} px-2 py-1 rounded-full text-xs`}>
                        {index % 2 === 0 ? 'Auction' : 'Buy Now'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Carousel indicators */}
          <div className="flex justify-center mt-6 space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#FFD700]"></div>
            <div className="w-3 h-3 rounded-full bg-gray-300"></div>
            <div className="w-3 h-3 rounded-full bg-gray-300"></div>
          </div>

          {/* How It Works Section */}
          <section className="w-full py-16">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center text-2xl font-bold text-white mx-auto mb-4">1</div>
                <h3 className="text-xl font-bold mb-2">Connect Wallet</h3>
                <p className="text-gray-600">Sign in with your Internet Identity or preferred wallet to access the platform securely.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center text-2xl font-bold text-white mx-auto mb-4">2</div>
                <h3 className="text-xl font-bold mb-2">Discover Art</h3>
                <p className="text-gray-600">Explore traditional and contemporary African art with verified authenticity and provenance.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center text-2xl font-bold text-white mx-auto mb-4">3</div>
                <h3 className="text-xl font-bold mb-2">Collect & Support</h3>
                <p className="text-gray-600">Purchase art directly from creators, supporting African artists and cultural preservation.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center text-2xl font-bold text-white mx-auto mb-4">4</div>
                <h3 className="text-xl font-bold mb-2">Share Heritage</h3>
                <p className="text-gray-600">Join a community preserving African art heritage while empowering the next generation of artists.</p>
              </div>
            </div>
          </section>

          {/* Featured Artists Section */}
          <section className="w-full py-16 bg-white">
            <div className="flex justify-between items-center mb-12">
              <h2 className="text-3xl font-bold">Featured Artists</h2>
              <a href="/artists" className="text-[#FFD700] hover:text-[#e5c100] font-medium">View All</a>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
              {[
                {
                  name: "Oluwaseun Adebayo",
                  country: "Nigeria",
                  items: 42,
                  sales: 156,
                  image: "https://randomuser.me/api/portraits/men/32.jpg"
                },
                {
                  name: "Aisha Kimathi",
                  country: "Kenya",
                  items: 38,
                  sales: 129,
                  image: "https://randomuser.me/api/portraits/women/44.jpg"
                },
                {
                  name: "Kofi Mensah",
                  country: "Ghana",
                  items: 31,
                  sales: 98,
                  image: "https://randomuser.me/api/portraits/men/62.jpg"
                },
                {
                  name: "Nala Berhane",
                  country: "Ethiopia",
                  items: 29,
                  sales: 87,
                  image: "https://randomuser.me/api/portraits/women/61.jpg"
                },
                {
                  name: "Tariq Abdelrahman",
                  country: "Egypt",
                  items: 25,
                  sales: 76,
                  image: "https://randomuser.me/api/portraits/men/81.jpg"
                }
              ].map((artist, index) => (
                <div key={index} className="text-center">
                  <img src={artist.image} alt={artist.name} className="w-24 h-24 rounded-full mx-auto mb-4" />
                  <h3 className="font-bold text-lg mb-1">{artist.name}</h3>
                  <p className="text-gray-500 mb-3">{artist.country}</p>
                  <div className="flex justify-center space-x-6">
                    <div>
                      <p className="font-bold">{artist.items}</p>
                      <p className="text-gray-500 text-sm">Items</p>
                    </div>
                    <div>
                      <p className="font-bold">{artist.sales}</p>
                      <p className="text-gray-500 text-sm">Sales</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Footer */}
          <footer className="w-full py-16 bg-gray-50">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h3 className="font-bold text-xl mb-4">AfriArt</h3>
                <p className="text-gray-600 mb-4">
                  The premier NFT marketplace for African art, preserving heritage and empowering contemporary artists through blockchain technology.
                </p>
              </div>
              <div>
                <h4 className="font-bold mb-4">Marketplace</h4>
                <ul className="space-y-2">
                  <li><a href="/marketplace" className="text-gray-600 hover:text-[#FFD700]">All NFTs</a></li>
                  <li><a href="/marketplace?category=contemporary" className="text-gray-600 hover:text-[#FFD700]">Contemporary Art</a></li>
                  <li><a href="/marketplace?category=traditional" className="text-gray-600 hover:text-[#FFD700]">Traditional Art</a></li>
                  <li><a href="/marketplace?category=sculptures" className="text-gray-600 hover:text-[#FFD700]">Sculptures</a></li>
                  <li><a href="/marketplace?category=digital" className="text-gray-600 hover:text-[#FFD700]">Digital Art</a></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-4">Resources</h4>
                <ul className="space-y-2">
                  <li><a href="/heritage" className="text-gray-600 hover:text-[#FFD700]">Heritage Archives</a></li>
                  <li><a href="/artists" className="text-gray-600 hover:text-[#FFD700]">Artist Stories</a></li>
                  <li><a href="/community" className="text-gray-600 hover:text-[#FFD700]">Community</a></li>
                  <li><a href="/blog" className="text-gray-600 hover:text-[#FFD700]">Blog</a></li>
                  <li><a href="/newsletter" className="text-gray-600 hover:text-[#FFD700]">Newsletter</a></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-4">Connect</h4>
                <div className="flex space-x-4">
                  <a href="#" className="text-gray-600 hover:text-[#FFD700]"><i className="fab fa-twitter"></i></a>
                  <a href="#" className="text-gray-600 hover:text-[#FFD700]"><i className="fab fa-instagram"></i></a>
                  <a href="#" className="text-gray-600 hover:text-[#FFD700]"><i className="fab fa-discord"></i></a>
                  <a href="#" className="text-gray-600 hover:text-[#FFD700]"><i className="fab fa-telegram"></i></a>
                </div>
              </div>
            </div>
            <div className="border-t border-gray-200 mt-12 pt-8 text-center text-gray-600">
              © 2025 AfriArt. All rights reserved.
            </div>
          </footer>
        </div>
      </div>
    </>
  );
};

export default HomePage; 