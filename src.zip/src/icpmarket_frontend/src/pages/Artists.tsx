import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const CATEGORIES = ['All', 'Digital Art', 'Photography', '3D Models', 'Music'] as const;
type Category = typeof CATEGORIES[number];

interface Artist {
  id: string;
  name: string;
  image: string;
  category: Category;
  artworks: number;
  followers: number;
  description: string;
}

const mockArtists: Artist[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    image: '/artists/artist1.jpg',
    category: 'Digital Art',
    artworks: 25,
    followers: 1200,
    description: 'Digital artist specializing in contemporary African art fusion.'
  },
  // Add more mock artists here
];

export default function Artists() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');

  const filteredArtists = mockArtists.filter(artist => {
    const matchesSearch = artist.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || artist.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold mb-6">Featured Artists</h1>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div className="flex flex-wrap gap-3 mb-4 md:mb-0">
            {CATEGORIES.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`${
                  selectedCategory === category
                    ? 'bg-amber-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                } px-4 py-2 rounded-full text-sm`}
              >
                {category}
              </button>
            ))}
          </div>
          
          <div className="relative w-full md:w-64">
            <input
              type="text"
              placeholder="Search artists..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
            />
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredArtists.map((artist) => (
          <div key={artist.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="relative">
              <img 
                src={artist.image} 
                alt={artist.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                <h3 className="text-white font-semibold text-lg">{artist.name}</h3>
                <p className="text-gray-300 text-sm">{artist.category}</p>
              </div>
            </div>
            
            <div className="p-4">
              <p className="text-gray-600 text-sm mb-4">{artist.description}</p>
              
              <div className="flex justify-between items-center mb-4">
                <div>
                  <p className="text-sm text-gray-500">Artworks</p>
                  <p className="font-semibold">{artist.artworks}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Followers</p>
                  <p className="font-semibold">{artist.followers}</p>
                </div>
              </div>
              
              <NavLink
                to={`/artists/${artist.id}`}
                className="block text-center bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition"
              >
                View Profile
              </NavLink>
            </div>
          </div>
        ))}
      </div>
      
      {filteredArtists.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No artists found matching your criteria.</p>
        </div>
      )}
    </div>
  );
} 