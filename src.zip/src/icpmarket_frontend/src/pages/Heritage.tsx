import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const REGIONS = ['All Regions', 'West Africa', 'East Africa', 'North Africa', 'Southern Africa', 'Central Africa'] as const;
const ERAS = ['All Eras', 'Ancient', 'Medieval', 'Colonial', 'Modern', 'Contemporary'] as const;
const CATEGORIES = ['All Categories', 'Artifacts', 'Art', 'Textiles', 'Jewelry', 'Sculptures'] as const;

type Region = typeof REGIONS[number];
type Era = typeof ERAS[number];
type Category = typeof CATEGORIES[number];

interface HeritageItem {
  id: string;
  title: string;
  image: string;
  region: Region;
  era: Era;
  category: Category;
  description: string;
  verifiedOrigin: boolean;
}

const mockHeritageItems: HeritageItem[] = [
  {
    id: '1',
    title: 'Ancient Benin Bronze',
    image: '/heritage/benin-bronze.jpg',
    region: 'West Africa',
    era: 'Ancient',
    category: 'Artifacts',
    description: 'A beautifully preserved bronze artifact from the ancient Benin kingdom.',
    verifiedOrigin: true
  },
  // Add more mock items here
];

export default function Heritage() {
  const [selectedRegion, setSelectedRegion] = useState<Region>('All Regions');
  const [selectedEra, setSelectedEra] = useState<Era>('All Eras');
  const [selectedCategory, setSelectedCategory] = useState<Category>('All Categories');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredItems = mockHeritageItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = selectedRegion === 'All Regions' || item.region === selectedRegion;
    const matchesEra = selectedEra === 'All Eras' || item.era === selectedEra;
    const matchesCategory = selectedCategory === 'All Categories' || item.category === selectedCategory;
    return matchesSearch && matchesRegion && matchesEra && matchesCategory;
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold mb-6">Cultural Heritage</h1>
        
        <div className="bg-white p-6 rounded-lg shadow-lg mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Region</label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value as Region)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                {REGIONS.map(region => (
                  <option key={region} value={region}>{region}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Era</label>
              <select
                value={selectedEra}
                onChange={(e) => setSelectedEra(e.target.value as Era)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                {ERAS.map(era => (
                  <option key={era} value={era}>{era}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as Category)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                {CATEGORIES.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
              <input
                type="text"
                placeholder="Search heritage items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredItems.map((item) => (
          <div key={item.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="relative">
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 right-2">
                {item.verifiedOrigin && (
                  <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                    Verified Origin
                  </span>
                )}
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                <span className="inline-block bg-amber-100 text-amber-800 text-xs font-medium px-2.5 py-0.5 rounded-full mb-2">
                  {item.era}
                </span>
                <h3 className="text-white font-semibold text-lg">{item.title}</h3>
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex gap-2 mb-3">
                <span className="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                  {item.category}
                </span>
                <span className="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                  {item.region}
                </span>
              </div>
              
              <p className="text-gray-600 text-sm mb-4">{item.description}</p>
              
              <NavLink
                to={`/heritage/${item.id}`}
                className="block text-center bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition"
              >
                Learn More
              </NavLink>
            </div>
          </div>
        ))}
      </div>
      
      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No heritage items found matching your criteria.</p>
        </div>
      )}
    </div>
  );
} 