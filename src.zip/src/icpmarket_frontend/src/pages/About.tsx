import React from 'react';
import { Link } from 'react-router-dom';

export default function About() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <section className="mb-20">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About AfriArt</h1>
          <p className="text-gray-600 text-lg leading-relaxed mb-8">
            The premier NFT marketplace for African art, preserving heritage and empowering artists through blockchain technology. Discover authentic African art from traditional indigenous pieces to modern African masterpieces.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/marketplace" className="bg-amber-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-amber-700">Explore Marketplace</Link>
            <Link to="/heritage" className="border border-amber-600 text-amber-600 px-6 py-3 rounded-lg font-medium hover:bg-amber-50">Explore Heritage</Link>
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="mb-20">
        <div className="card max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-center">Our Mission</h2>
          <p className="text-gray-600 mb-6 leading-relaxed">
            AfriArt was founded with a simple but powerful mission: to empower African artists and preserve cultural heritage by providing a dedicated platform to showcase creativity, document historical artifacts, and ensure fair compensation through direct connections with a global audience.
          </p>
          <p className="text-gray-600 mb-6 leading-relaxed">
            We believe that African art, both contemporary and traditional, represents an incredibly rich cultural heritage that deserves wider recognition and appreciation. By leveraging blockchain technology, we're creating a more equitable art marketplace that values creators first, preserves provenance and authenticity, and ensures artists receive fair compensation for their work.
          </p>
          <p className="text-gray-600 leading-relaxed">
            Our platform is built on the Internet Computer Protocol, which offers a truly decentralized and censorship-resistant foundation for digital ownership. This ensures that artists maintain complete control over their creative assets while benefiting from the security and transparency that blockchain technology provides.
          </p>
        </div>
      </section>

      {/* Platform Features */}
      <section className="mb-20">
        <h2 className="text-3xl font-bold mb-10 text-center">Platform Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="card text-center">
            <div className="w-16 h-16 bg-amber-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-certificate"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">Verified Authenticity</h3>
            <p className="text-gray-600">
              Each artwork is verified for authenticity, with digital provenance tracked on the blockchain to ensure legitimate African origin and artist attribution.
            </p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-amber-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-wallet"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">Automatic Royalties</h3>
            <p className="text-gray-600">
              Artists earn royalties automatically on every secondary sale, providing ongoing income from their creations and supporting sustainable careers.
            </p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-amber-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-history"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">Heritage Preservation</h3>
            <p className="text-gray-600">
              Our digital archive preserves traditional and indigenous African art with detailed cultural context and historical documentation.
            </p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-amber-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-users"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">Artist Community</h3>
            <p className="text-gray-600">
              Connect directly with African artists from across the continent, learn about their cultural influences and artistic journeys.
            </p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-amber-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-hand-holding-usd"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">Flexible Selling Options</h3>
            <p className="text-gray-600">
              Creators can choose between fixed-price listings or auctions to maximize their earnings potential and reach the right collectors.
            </p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-amber-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-map-marked-alt"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">Regional Showcases</h3>
            <p className="text-gray-600">
              Special featured collections highlighting the diverse artistic traditions from different regions of Africa, from North to South.
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="mb-20">
        <h2 className="text-3xl font-bold mb-10 text-center">Meet Our Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              name: "David Dziedzom",
              role: "Founder",
              bio: "Ashesi University Student",
              image: ""
            },
            {
              name: "Emmanuel Adoum",
              role: "Founder",
              bio: "Ashesi University Student",
              image: ""
            },
            {
              name: "Andrew Quarcoo",
              role: "Technical Lead",
              bio: "Ashesi University Student",
              image: ""
            },
          ].map((member, index) => (
            <div key={index} className="card text-center">
              <img 
                src={member.image}
                alt={member.name}
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h3 className="text-xl font-bold">{member.name}</h3>
              <p className="text-amber-600 mb-2">{member.role}</p>
              <p className="text-gray-600">{member.bio}</p>
              <div className="flex justify-center mt-4 space-x-3">
                <a href="#" className="text-gray-400 hover:text-amber-600">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-amber-600">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-amber-600">
                  <i className="fab fa-github"></i>
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="mb-20">
        <h2 className="text-3xl font-bold mb-10 text-center">Frequently Asked Questions</h2>
        <div className="max-w-3xl mx-auto space-y-6">
          {[
            {
              question: "What type of art can I find on AfriArt?",
              answer: "AfriArt features a diverse range of authentic African art, including traditional indigenous artifacts with historical significance, contemporary fine art by established and emerging African artists, digital art with African cultural influences, and physical artworks that have been tokenized on the blockchain."
            },
            {
              question: "How do you verify the authenticity of traditional artifacts?",
              answer: "We work with museums, cultural institutions, and expert authenticators to verify the origin, age, and cultural context of traditional artifacts. Each heritage item includes detailed provenance information, certification of authenticity, and cultural background to ensure respectful and accurate representation."
            },
            {
              question: "How do I create and sell an NFT on AfriArt?",
              answer: "Creating an NFT on AfriArt is simple! Connect your wallet, click 'Create' in the navigation, upload your digital artwork, fill in details like title, description, and set your price or auction parameters. Your artwork will be permanently stored on the blockchain and available for sale to collectors worldwide."
            },
            {
              question: "What are the fees for using AfriArt?",
              answer: "We charge a minimal platform fee of 2.5% on each sale, which is significantly lower than traditional galleries or other NFT marketplaces. Artists also set their own royalty percentage (typically 5-15%) that they receive on all secondary sales, ensuring ongoing compensation."
            },
            {
              question: "How does AfriArt support cultural preservation?",
              answer: "Beyond the marketplace, we actively document and digitize traditional African art forms, many of which are at risk of being lost. A portion of platform fees goes to our Cultural Heritage Fund, which supports digitization projects, artist education programs, and collaborations with cultural institutions across Africa."
            }
          ].map((item, index) => (
            <div key={index} className="card">
              <h3 className="text-xl font-bold mb-3">{item.question}</h3>
              <p className="text-gray-600">{item.answer}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section>
        <div className="bg-amber-600 text-white rounded-xl p-8 md:p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Explore African Art?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Discover authentic African artworks, support talented artists, and become part of a community dedicated to preserving and celebrating Africa's rich artistic heritage.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/marketplace" className="bg-white text-amber-600 px-6 py-3 rounded-lg font-medium hover:bg-gray-100">
              Explore the Marketplace
            </Link>
            <Link to="/heritage" className="bg-amber-700 text-white px-6 py-3 rounded-lg font-medium hover:bg-amber-800">
              Discover Heritage Collection
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
} 