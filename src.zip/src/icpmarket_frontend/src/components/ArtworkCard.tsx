import React from 'react';

interface ArtworkCardProps {
  id: bigint;
  title: string;
  artist: string;
  price: bigint;
  image: string;
  status: 'forSale' | 'notListed' | 'auction';
  onPurchase?: () => void;
  onList?: () => void;
}

const ArtworkCard: React.FC<ArtworkCardProps> = ({
  id,
  title,
  artist,
  price,
  image,
  status,
  onPurchase,
  onList
}) => {
  // Convert price from e8s to ICP (1 ICP = 100_000_000 e8s)
  const priceInICP = Number(price) / 100_000_000;

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition duration-300">
      <div className="relative">
        <img 
          src={image} 
          alt={title}
          className="w-full h-48 object-cover"
        />
        {status === 'auction' && (
          <div className="absolute top-2 right-2 bg-black bg-opacity-70 text-[#FFD700] px-3 py-1 rounded-full text-sm">
            Live Auction
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2">{title}</h3>
        <div className="flex items-center mb-3">
          <div className="w-6 h-6 rounded-full bg-gray-200 mr-2"></div>
          <span className="text-sm text-gray-600">{artist}</span>
        </div>
        
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-500">Current {status === 'auction' ? 'Bid' : 'Price'}</p>
            <p className="text-lg font-bold text-[#FFD700]">{priceInICP.toFixed(2)} ICP</p>
          </div>
          {status === 'forSale' && onPurchase && (
            <button
              onClick={onPurchase}
              className="bg-[#FFD700] text-black px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90"
            >
              Buy Now
            </button>
          )}
          {status === 'notListed' && onList && (
            <button
              onClick={onList}
              className="bg-black text-[#FFD700] px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-900"
            >
              List for Sale
            </button>
          )}
          {status === 'auction' && (
            <button className="bg-black text-[#FFD700] px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-900">
              Place Bid
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ArtworkCard; 