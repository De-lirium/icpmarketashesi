import React from 'react';
import { useAuth } from '../contexts/AuthContext';

export function ConnectWallet() {
  const { isAuthenticated, principal, login, logout } = useAuth();

  // Display a truncated version of the principal for better UI
  const displayPrincipal = () => {
    if (!principal) return '...';
    const principalStr = principal.toString();
    return principalStr.length > 10 ? `${principalStr.slice(0, 5)}...${principalStr.slice(-5)}` : principalStr;
  };

  return (
    <div>
      {isAuthenticated ? (
        <div className="flex flex-col sm:flex-row items-center">
          <span className="text-xs text-gray-600 mr-2 mb-2 sm:mb-0">
            {displayPrincipal()}
          </span>
          <button
            onClick={() => logout()}
            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors text-sm"
          >
            Disconnect
          </button>
        </div>
      ) : (
        <button
          onClick={() => login()}
          className="px-4 py-2 bg-amber-600 text-white rounded hover:bg-amber-700 transition-colors"
        >
          Connect Wallet
        </button>
      )}
    </div>
  );
} 