import React from 'react';

const EventBanner: React.FC = () => {
  return (
    <div className="bg-black text-white py-3">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-center text-center">
          <span className="font-bold text-[#FFD700] mr-2">Special Exhibition:</span>
          <span className="mr-4">Contemporary African Art Showcase - May 15-30, 2023</span>
          <a href="/events" className="text-[#FFD700] underline mt-2 md:mt-0">Learn More</a>
        </div>
      </div>
    </div>
  );
};

export default EventBanner; 