import React, { useState, useEffect, ChangeEvent, FormEvent } from 'react';
import { registerUser, updateProfile } from '../lib/canister';
import { UserProfile as UserProfileType, UpdateProfileResult } from '../types';

const UserProfile: React.FC = () => {
  const [username, setUsername] = useState<string>('');
  const [bio, setBio] = useState<string>('');
  const [profilePicture, setProfilePicture] = useState<Uint8Array | null>(null);
  const [isRegistered, setIsRegistered] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');

  const handleProfilePictureChange = (e: ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const arrayBuffer = reader.result as ArrayBuffer;
        setProfilePicture(new Uint8Array(arrayBuffer));
      };
      reader.readAsArrayBuffer(file);
    }
  };

  const handleRegisterUser = async (e: FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!username || !bio || !profilePicture) {
      setMessage('Please fill all fields and select a profile picture');
      return;
    }

    try {
      setIsLoading(true);
      const result = await registerUser(username, bio, profilePicture);
      
      if (result) {
        setIsRegistered(true);
        setMessage('Profile registered successfully!');
      } else {
        setMessage('You are already registered or registration failed.');
      }
      setIsLoading(false);
    } catch (err) {
      setMessage('Failed to register profile');
      setIsLoading(false);
      console.error(err);
    }
  };

  const handleUpdateProfile = async (e: FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!username || !bio || !profilePicture) {
      setMessage('Please fill all fields and select a profile picture');
      return;
    }

    try {
      setIsLoading(true);
      const result = await updateProfile(username, bio, profilePicture);
      
      if ('Success' in result) {
        setMessage('Profile updated successfully!');
      } else if ('UserNotFound' in result) {
        setMessage('User not found. Please register first.');
      } else {
        setMessage('Failed to update profile.');
      }
      setIsLoading(false);
    } catch (err) {
      setMessage('Failed to update profile');
      setIsLoading(false);
      console.error(err);
    }
  };

  return (
    <section className="profile-section" id="profile">
      <h2>Your Profile</h2>
      {message && <p className={message.includes('success') ? 'success-message' : 'error-message'}>{message}</p>}
      
      <form onSubmit={isRegistered ? handleUpdateProfile : handleRegisterUser} className="profile-form">
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input 
            type="text" 
            id="username" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)} 
            required 
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="bio">Bio</label>
          <textarea 
            id="bio" 
            value={bio} 
            onChange={(e) => setBio(e.target.value)} 
            required 
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="profile-picture">Profile Picture</label>
          <input 
            type="file" 
            id="profile-picture" 
            accept="image/*" 
            onChange={handleProfilePictureChange} 
            required 
          />
        </div>
        
        <button 
          type="submit" 
          className="btn profile-btn"
          disabled={isLoading}
        >
          {isLoading ? 'Processing...' : isRegistered ? 'Update Profile' : 'Register Profile'}
        </button>
      </form>
    </section>
  );
};

export default UserProfile; 