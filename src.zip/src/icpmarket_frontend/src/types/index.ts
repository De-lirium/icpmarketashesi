import { Principal } from '@dfinity/principal';

export interface NFT {
  id: bigint;
  owner: Principal;
  image: Uint8Array;
  title: string;
  description: string;
  price: bigint;
  isListed: boolean;
  category: string;
}

export interface UserProfile {
  username: string;
  bio: string;
  profilePicture: Uint8Array;
}

export type UpdateProfileResult = 
  | { Success: UserProfile }
  | { UserNotFound: string }
  | { UpdateFailed: string };

export interface Auction {
  id: bigint;
  nftId: bigint;
  startingPrice: bigint;
  highestBid: bigint;
  highestBidder: Principal | null;
  startTime: bigint;
  endTime: bigint;
  isActive: boolean;
} 