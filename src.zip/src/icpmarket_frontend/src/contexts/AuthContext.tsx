import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthClient } from '@dfinity/auth-client';
import { Actor, HttpAgent } from '@dfinity/agent';
import { Principal } from '@dfinity/principal';
import { initializeBackend } from '../lib/canister';

interface AuthContextType {
  isAuthenticated: boolean;
  principal: Principal | null;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  backend: any | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [principal, setPrincipal] = useState<Principal | null>(null);
  const [backend, setBackend] = useState<any | null>(null);

  useEffect(() => {
    // Check for existing authentication on mount
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const authClient = await AuthClient.create();
      const isAuthed = await authClient.isAuthenticated();
      if (isAuthed) {
        const identity = authClient.getIdentity();
        const principalStr = identity.getPrincipal().toString();
        setPrincipal(Principal.fromText(principalStr));
        setIsAuthenticated(true);
        // Initialize backend with authenticated identity
        const backendActor = await initializeBackend(identity);
        setBackend(backendActor);
      }
    } catch (error) {
      console.error('Error checking authentication:', error);
    }
  };

  const handleSuccess = async (authClient: AuthClient) => {
    try {
      const identity = authClient.getIdentity();
      const principalStr = identity.getPrincipal().toString();
      setPrincipal(Principal.fromText(principalStr));
      setIsAuthenticated(true);
      
      // Initialize backend with authenticated identity
      const backendActor = await initializeBackend(identity);
      setBackend(backendActor);
    } catch (error) {
      console.error('Error handling successful login:', error);
    }
  };

  const login = async () => {
    try {
      const authClient = await AuthClient.create();
      
      const isLocalDev = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
      const identityProvider = isLocalDev
        ? `http://bnz7o-iuaaa-aaaaa-qaaaa-cai.localhost:4943/`  // Local II canister
        : 'https://identity.ic0.app/';  // Production II service

      await authClient.login({
        identityProvider,
        onSuccess: () => handleSuccess(authClient),
        maxTimeToLive: BigInt(7 * 24 * 60 * 60 * 1000 * 1000 * 1000), // 7 days in nanoseconds
      });
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const logout = async () => {
    try {
      const authClient = await AuthClient.create();
      await authClient.logout();
      setPrincipal(null);
      setIsAuthenticated(false);
      setBackend(null);
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, principal, login, logout, backend }}>
      {children}
    </AuthContext.Provider>
  );
}; 