/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'custom-bg': '#fff8f1', // Light cream - sand
        primary: '#e67e22', // Orange/amber - representing African sunset
        secondary: '#2c3e50', // Dark blue - night sky
        accent: '#27ae60', // Green - representing vegetation
      },
      fontFamily: {
        sans: ['Poppins', 'sans-serif'],
      },
    },
  },
  plugins: [],
}